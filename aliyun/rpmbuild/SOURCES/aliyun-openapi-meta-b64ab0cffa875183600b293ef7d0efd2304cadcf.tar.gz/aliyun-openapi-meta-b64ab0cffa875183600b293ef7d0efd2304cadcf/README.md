# Aliyun OpenAPI Meta Data 

- 阿里云OpenAPI元数据，目前仅用于[aliyun-cli](https://github.com/aliyun/aliyun-cli)工具的构建，注意此数据目前处于非稳定期，随时可能变动
	
- This meta data is aliyun OpenAPI products and api information, now is only for [aliyun-cli](https://github.com/aliyun/aliyun-cli) build, the structure is not stable will change further.
	

	
	