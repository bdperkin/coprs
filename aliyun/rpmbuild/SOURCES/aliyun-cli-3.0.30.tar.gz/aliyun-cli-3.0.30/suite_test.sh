aliyun ecs DescribeRegions

