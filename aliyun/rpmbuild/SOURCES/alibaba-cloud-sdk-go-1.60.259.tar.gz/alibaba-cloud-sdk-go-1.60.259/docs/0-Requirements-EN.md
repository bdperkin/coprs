[← Home](../README.md) | Requirements[(中文)](0-Requirements-CN.md) | [Installation →](1-Installation-EN.md)
***

## Requirements
- You must use Go 1.10.x or later.

## Recommendations
- Please make sure there will be no conflict between Alibaba Cloud SDK for Go and other. You can see specific constraints in [Gopkg.toml](../Gopkg.toml).

***
[← Home](../README.md) | Requirements[(中文)](0-Requirements-CN.md) | [Installation →](1-Installation-EN.md)
