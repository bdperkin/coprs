package signers

type SessionCredential struct {
	AccessKeyId     string
	AccessKeySecret string
	StsToken        string
}
