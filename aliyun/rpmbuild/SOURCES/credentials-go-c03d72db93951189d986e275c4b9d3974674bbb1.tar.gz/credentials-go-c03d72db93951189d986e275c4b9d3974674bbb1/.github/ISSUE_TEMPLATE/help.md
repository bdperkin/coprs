---
name: "⁉️ Need help with Alibaba Cloud?"
about: Please submit a work order in our work order system

---

If you have a question about Alibaba Cloud that is not a bug report or feature
request, please post it in https://selfservice.console.aliyun.com/ticket/createIndex

Questions posted to this repository will be closed.