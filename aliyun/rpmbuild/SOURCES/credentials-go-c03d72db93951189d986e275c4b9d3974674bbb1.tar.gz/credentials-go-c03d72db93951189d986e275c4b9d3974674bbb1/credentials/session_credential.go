package credentials

type sessionCredential struct {
	AccessKeyID     string
	AccessKeySecret string
	SecurityToken   string
}
