# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
class ShopShowListRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'cloudwf', '2017-03-28', 'ShopShowList','cloudwf')

	def get_Gid(self):
		return self.get_query_params().get('Gid')

	def set_Gid(self,Gid):
		self.add_query_param('Gid',Gid)

	def get_Address(self):
		return self.get_query_params().get('Address')

	def set_Address(self,Address):
		self.add_query_param('Address',Address)

	def get_Name(self):
		return self.get_query_params().get('Name')

	def set_Name(self,Name):
		self.add_query_param('Name',Name)

	def get_Dirc(self):
		return self.get_query_params().get('Dirc')

	def set_Dirc(self,Dirc):
		self.add_query_param('Dirc',Dirc)

	def get_Page(self):
		return self.get_query_params().get('Page')

	def set_Page(self,Page):
		self.add_query_param('Page',Page)

	def get_Bid(self):
		return self.get_query_params().get('Bid')

	def set_Bid(self,Bid):
		self.add_query_param('Bid',Bid)

	def get_Per(self):
		return self.get_query_params().get('Per')

	def set_Per(self,Per):
		self.add_query_param('Per',Per)

	def get_ShopStatus(self):
		return self.get_query_params().get('ShopStatus')

	def set_ShopStatus(self,ShopStatus):
		self.add_query_param('ShopStatus',ShopStatus)