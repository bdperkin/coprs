# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from aliyunsdkcore.request import RpcRequest
class RemoveParticipantsRequest(RpcRequest):

	def __init__(self):
		RpcRequest.__init__(self, 'rtc', '2018-01-11', 'RemoveParticipants','rtc')

	def get_ParticipantIdss(self):
		return self.get_query_params().get('ParticipantIdss')

	def set_ParticipantIdss(self,ParticipantIdss):
		for i in range(len(ParticipantIdss)):	
			if ParticipantIdss[i] is not None:
				self.add_query_param('ParticipantIds.' + str(i + 1) , ParticipantIdss[i]);

	def get_OwnerId(self):
		return self.get_query_params().get('OwnerId')

	def set_OwnerId(self,OwnerId):
		self.add_query_param('OwnerId',OwnerId)

	def get_ConferenceId(self):
		return self.get_query_params().get('ConferenceId')

	def set_ConferenceId(self,ConferenceId):
		self.add_query_param('ConferenceId',ConferenceId)

	def get_AppId(self):
		return self.get_query_params().get('AppId')

	def set_AppId(self,AppId):
		self.add_query_param('AppId',AppId)