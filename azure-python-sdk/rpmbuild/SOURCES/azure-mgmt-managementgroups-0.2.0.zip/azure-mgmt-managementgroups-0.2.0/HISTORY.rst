.. :changelog:

Release History
===============

0.2.0 (2019-02-21)
++++++++++++++++++

**Features**

- Model EntityInfo has a new parameter number_of_children
- Model EntityInfo has a new parameter number_of_child_groups

0.1.0 (2018-05-31)
++++++++++++++++++

* Initial Release
