azure.core.polling
==================

.. automodule:: azure.core.polling
   :members:
   :undoc-members:
   :inherited-members:
