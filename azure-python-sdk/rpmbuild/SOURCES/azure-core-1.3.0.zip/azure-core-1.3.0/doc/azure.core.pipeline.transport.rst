azure.core.pipeline.transport
=============================

.. automodule:: azure.core.pipeline.transport
   :members:
   :undoc-members:
   :inherited-members:
