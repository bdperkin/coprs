.. :changelog:

Release History
===============

0.1.1 (2019-05-17)
++++++++++++++++++

**Features**

- Model PartnerResponse has a new parameter partner_name
- Added operation group PartnersOperations

0.1.0 (2018-02-06)
++++++++++++++++++

* Initial Release
