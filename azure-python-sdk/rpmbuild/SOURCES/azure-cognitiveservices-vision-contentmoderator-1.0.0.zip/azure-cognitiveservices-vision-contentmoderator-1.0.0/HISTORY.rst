.. :changelog:

Release History
===============

1.0.0 (2019-01-02)
++++++++++++++++++

* Initial stable release

0.1.0 (2018-02-06)
++++++++++++++++++

* Initial Release
