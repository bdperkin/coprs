.. :changelog:

Release History
===============

0.1.1 (2019-02-14)
++++++++++++++++++

Bug fix: Fixed an enum comment's erroneous wrap around

0.1.0 (2019-02-11)
++++++++++++++++++

* Initial Release
