# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# -----------------------------------

TEST_SERVICE_NAME = "test-service-name"
SERVICE_URL = "https://{}.search.windows.net/indexes?api-version=2019-05-06".format(
    TEST_SERVICE_NAME
)
