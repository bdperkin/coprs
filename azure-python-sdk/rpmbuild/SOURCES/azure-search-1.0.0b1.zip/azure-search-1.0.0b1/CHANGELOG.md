# Release History

## 1.0.0b1 (2020-03-10)

First release of Azure Search SDK for Python
