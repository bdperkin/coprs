.. :changelog:

Release History
===============

0.2.0 (2019-05-23)
++++++++++++++++++

**Features**

- Model ControllerUpdateParameters has a new parameter target_container_host_credentials_base64
- Added operation group ContainerHostMappingsOperations

**Breaking changes**

- Operation ControllersOperations.list_connection_details has a new signature
- Operation ControllersOperations.update has a new signature
- Model ControllerConnectionDetails has a new signature

0.1.0 (2018-07-12)
++++++++++++++++++

* Initial Release
