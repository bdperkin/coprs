# Microsoft Azure SDK for Python

This is the Microsoft Azure common code.

This package provides shared code by the Azure packages.

If you are looking to install the Azure client libraries, refer to the main Github repository:
https://github.com/Azure/azure-sdk-for-python


![Impressions](https://azure-sdk-impressions.azurewebsites.net/api/impressions/azure-sdk-for-python%2Fazure-common%2FREADME.png)
