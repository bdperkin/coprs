.. :changelog:

Release History
===============

0.1.1 (2019-10-30)
++++++++++++++++++

- Update project description and title

0.1.0 (2019-10-29)
++++++++++++++++++

**Breaking changes**

- Removed MachineExtensionsOperations

0.1.0rc1 (2019-10-23)
+++++++++++++++++++++

* Initial Release
