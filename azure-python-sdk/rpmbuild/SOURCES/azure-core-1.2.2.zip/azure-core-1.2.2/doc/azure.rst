azure package
=============

.. automodule:: azure
   :members:
   :undoc-members:
   :inherited-members:

Subpackages
-----------

.. toctree::

   azure.core
