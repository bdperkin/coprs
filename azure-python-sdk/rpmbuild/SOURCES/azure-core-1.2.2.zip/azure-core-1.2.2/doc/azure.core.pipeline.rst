azure.core.pipeline
===================

.. automodule:: azure.core.pipeline
   :members:
   :undoc-members:
   :inherited-members:

Subpackages
-----------

.. toctree::

   azure.core.pipeline.policies
   azure.core.pipeline.transport
