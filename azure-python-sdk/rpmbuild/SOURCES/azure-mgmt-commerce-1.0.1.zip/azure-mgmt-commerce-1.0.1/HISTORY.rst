.. :changelog:

Release History
===============

1.0.1 (2018-02-21)
++++++++++++++++++

- usage_aggregation.quantity is now correctly declared as float
- All operation groups have now a "models" attribute

1.0.0 (2017-06-23)
++++++++++++++++++

* Initial stable release

This wheel package is now built with the azure wheel extension

If moved from 0.30.0rc6, expect some tiny renaming like (not exhaustive):

- reportedstart_time renamed to reported_start_time
- self.Name renamed to self.name in some classes
