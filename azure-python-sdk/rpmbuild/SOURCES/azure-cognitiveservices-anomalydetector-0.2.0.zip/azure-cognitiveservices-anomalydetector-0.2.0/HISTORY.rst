.. :changelog:

Release History
===============

0.2.0 (2019-04-12)
++++++++++++++++++

**Bugfixes**

- Fix some syntax error in the initial release

0.1.0 (2019-04-10)
++++++++++++++++++

* Initial Release
