.. :changelog:

Release History
===============

0.2.0 (2019-11-12)
++++++++++++++++++

**Features**

- Added operation CachesOperations.create_or_update
- Added operation StorageTargetsOperations.create_or_update

**Breaking changes**

- Removed operation CachesOperations.create
- Removed operation StorageTargetsOperations.create
- Removed operation StorageTargetsOperations.update

0.1.0rc1 (2019-09-03)
+++++++++++++++++++++

* Initial Release
