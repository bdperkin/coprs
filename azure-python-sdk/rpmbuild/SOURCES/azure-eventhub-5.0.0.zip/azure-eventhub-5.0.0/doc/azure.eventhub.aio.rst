azure.eventhub.aio package
==========================

    .. autoclass:: azure.eventhub.aio.EventHubConsumerClient
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.aio.EventHubProducerClient
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.aio.EventHubSharedKeyCredential
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.aio.CheckpointStore
        :members:
        :undoc-members:
        :inherited-members:

    .. autoclass:: azure.eventhub.aio.PartitionContext
        :members:
        :undoc-members:
        :inherited-members:
