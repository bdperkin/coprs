.. :changelog:

Release History
===============

0.1.3 (2017-05-02)
++++++++++++++++++

* Added property enableAutomaticFailover and consistencyPolicy ConsistentPrefix

0.1.2 (2017-04-20)
++++++++++++++++++

This wheel package is now built with the azure wheel extension

0.1.1 (2017-03-21)
++++++++++++++++++

* Added support for listing database account connection strings

0.1.0 (2017-01-31)
++++++++++++++++++

* Initial Release
