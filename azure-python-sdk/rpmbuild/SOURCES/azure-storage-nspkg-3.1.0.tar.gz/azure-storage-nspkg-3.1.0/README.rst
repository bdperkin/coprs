Microsoft Azure Storage SDK for Python
======================================

This is the Microsoft Azure Storage namespace package.

This package is not intended to be installed directly by the end user.

It provides the necessary files for other packages to extend the azure.storage namespace.

If you are looking to install the Azure Storage libraries, see the
`azure <https://pypi.python.org/pypi/azure>`__ bundle package.
