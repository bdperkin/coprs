# Release History
## 0.2.0 (2020-02-18)
+++++++++++++++++++++

**Features**

- Model EnvironmentStatus has a new parameter warm_storage

**Breaking changes**

- Operation EnvironmentsOperations.update has a new signature
- Model EnvironmentResource has a new signature
- Model EnvironmentUpdateParameters has a new signature
- Model EnvironmentCreateOrUpdateParameters has a new signature

## 0.1.0 (2020-01-15)

  - Initial Release
