.. :changelog:

Release History
===============

0.2.0 (2019-10-31)
++++++++++++++++++

**Features**

- Model VirtualNic has a new parameter customization
- Model VirtualMachine has a new parameter customization
- Added operation group CustomizationPoliciesOperations

0.1.0 (2019-10-08)
++++++++++++++++++

* Initial Release
