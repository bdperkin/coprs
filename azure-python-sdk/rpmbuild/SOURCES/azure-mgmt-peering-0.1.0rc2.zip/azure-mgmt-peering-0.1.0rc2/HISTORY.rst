.. :changelog:

Release History
===============

0.1.0rc2 (2019-10-24)
+++++++++++++++++++++

**Breaking changes**

- Migrated operations from PeeringServicePrefixesOperations to PrefixesOperations

0.1.0rc1 (2019-09-26)
+++++++++++++++++++++

* Initial Release
