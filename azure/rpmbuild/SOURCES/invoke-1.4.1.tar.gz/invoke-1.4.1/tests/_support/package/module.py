from invoke import task


@task
def mytask(c):
    pass
