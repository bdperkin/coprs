from invoke import task


@task
def alt_root(c):
    print("Down with the alt-root!")
