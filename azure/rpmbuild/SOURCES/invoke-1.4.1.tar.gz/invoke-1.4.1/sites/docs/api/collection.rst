==============
``collection``
==============

.. autoclass:: invoke.collection.Collection
    :special-members:
    :exclude-members: __weakref__, __init__
