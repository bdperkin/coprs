.. :changelog:

Release History
===============
2.0.3
+++++
* Indicate Python 3.7 support.

2.0.2
++++++
* Minor fixes.

2.0.1
+++++
* minor fixes

2.0.0 (2017-04-28)
++++++++++++++++++
* Initial release
