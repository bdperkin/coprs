.. :changelog:

Release History
===============
3.0.4
+++++
* Indicate Python 3.7 support.

3.0.3
++++++
* Minor fixes.

3.0.2
+++++
* minor fixes

3.0.1
+++++
* minor fixes

3.0.0 (2016-04-28)
++++++++++++++++++

* New nspkg structure.

2.0.0 (2016-02-27)
++++++++++++++++++

* GA release.

0.1.2 (2016-01-30)
++++++++++++++++++

* Support Python 3.6.

0.1.1 (2016-01-17)
++++++++++++++++++

* Stable release (no code changes since previous version).

0.1.0b11 (2016-12-12)
+++++++++++++++++++++

* Preview release.
