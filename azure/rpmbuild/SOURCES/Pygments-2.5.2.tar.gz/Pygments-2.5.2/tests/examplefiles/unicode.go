package main

import "fmt"

func main() {
    世界 := "Hello, world!"
    さようなら := "Goodbye, world!"
    fmt.Println(世界)
    fmt.Println(さようなら)
}
