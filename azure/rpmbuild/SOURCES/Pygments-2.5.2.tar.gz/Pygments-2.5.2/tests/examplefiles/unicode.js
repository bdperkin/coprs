var école;
var sinθ;
var เมือง;
var a\u1234b;

var nbsp;
