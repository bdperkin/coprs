void* operator new (std::size_t size);
void* operator new (std::size_t size, const std::nothrow_t& nothrow_value) noexcept;
void* operator new (std::size_t size, const std::nothrow_t& nothrow_value)noexcept;
void* operator new (std::size_t size, const std::nothrow_t& nothrow_value);
void* operator new (std::size_t size);
void* operator new (std::size_t size) noexcept;
void* operator new (std::size_t size)noexcept;

